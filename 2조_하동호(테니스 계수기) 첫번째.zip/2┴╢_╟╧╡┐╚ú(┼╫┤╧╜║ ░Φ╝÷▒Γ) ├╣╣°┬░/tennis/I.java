package tennis;

public interface I {

	void pointWinner(int p) ; //추상메서드
		
	void dispScoreBoard();

} //interface
